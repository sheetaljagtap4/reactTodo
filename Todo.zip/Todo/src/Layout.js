import React, { Component } from 'react';

export default class Layout extends Component {
    constructor(props){
          super();
          this.state={
              age : props.age,
          }
          this.makemeolder = this.makemeolder.bind(this)
          
      }
       makemeolder(){
          // console.log(this.age);
           this.setState({
               
               age : this.state.age+3
           })
            
        }
  render() {
      //console.log(this.props)
      
    return (
        <div>
            
            
        </div>
    )
  }
 
}

Layout.prototypes = {

}