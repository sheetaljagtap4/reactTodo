import React, { Component } from 'react';
import Todo from "./Todo"

import './App.css';
import Layout from './Layout.js'

class App extends Component {
  render() {
    var user={
      name: "Anna",
      hobbies: ['sports','cooking','reading']
    }
    return (
      <div className="App">
        <header >
          
          <h1 className="App-title">Welcome </h1>
          
          <Layout name="Max" age={20} user={user}/>
            <Todo/>
           
        </header>
        
      </div>
    );
  }
}

export default App;
