import React, { Component } from 'react';

export default class Todo extends Component {
    constructor(){
         super();
        this.state={
            text: [
                {task:"Go to the gym", done: false }, 
            ],
            narray: [
                 {task:"Go to the gym", done: false }, 
            ],
            checkedElem:[],
            elem: null,
            
            arrayToDisplay: [{task:"Go to the gym", done: false }, ],
            
           
        }

       // this.arrayToDisplay = this.state.text.slice();
        this.display = this.display.bind(this);
        
        this.storeElements = this.storeElements.bind(this);
        this.setChangedVal = this.setChangedVal.bind(this);
        this.showAll = this.showAll.bind(this);
        this.showActive = this.showActive.bind(this)
        this.showCompleted = this.showCompleted.bind(this)
        
    }
  render() {
     console.log('arrayToDisplay' + this.state.arrayToDisplay);
     let idd=0;
      

      console.log("text" + this.state.text)
     

    return (
        <div className=" container-fluid well halfwidth">
             <form onSubmit={this.display} >
                <div className="row">
                    <div className="form-group col-md-10">
                        <input type="text" className="form-control " id="usr"/>
                    </div>
                    <div className="form-group col-md-2">
                        <button type="button" className="btn btn-primary " >Add</button>
                    </div>

                    
                    <div className="textCenter col-md-12">
                        {
                            this.state.arrayToDisplay.map( (rr,index) => 
                    
                        <div  className="checkbox checkbox-circle">
                           
                                <input  key={index} type="checkbox" onChange={this.setChangedVal} data-id={idd++}  checked={rr.done}/>
                                <label> 
                                <div className="">   {rr.task} </div>
                                </label>
                            
                        </div>)}
                        
                    </div>
                   

                    <footer>
                        <div className="col-md-2">
                                item left    
                         </div>
                         <div>
                            <ul className="list-inline col-md-6">
                                    <li><a href="" onClick={this.showAll}>All</a></li>
                                <li><a href="" onClick={this.showActive}>Active</a></li>
                                <li><a href="" onClick={this.showCompleted}>Completed</a></li>
                            </ul>   
                        </div>
                        <div className="fright col-md-4">
                           
                             <a href=""> Clear completed</a>
                        </div>
                    </footer>
                </div>
             </form>
        </div>
    )
  }

  display(event){
      
      event.preventDefault();
      console.log(event.target)
      // console.log(event.target.querySelector('[data-id]') )
       //console.log(event.target.getAttribute('[data-id]')  )
       var a1 = event.target.querySelectorAll('[data-id]');
       console.log( a1)
      
       var length = a1.length;
       console.log('leng' + length)
      // console.log("err" + a1[length-1].getAttribute('data-id'));
       
        
        this.setState({
           
            text: this.state.text.concat({task: document.getElementById('usr').value, done:false, id: Number( a1[length-1].getAttribute('data-id'))+1 }),
                     
        })    
         var clonedArray = this.state.text.slice();
      //console.log('clonedd' + clonedArray);

       this.setState({
         arrayToDisplay: clonedArray,
       })
       
       
        event.target.querySelector('input').value='';       
    }

     storeElements(e){
        //console.log(e.target);
        if(e.target.checked === true){
           this.setState({
               checkedElem: this.state.checkedElem.concat(e.target.innerHTML)
           })

          
        }
         //console.log(this.state.checkedElem)
                
    }
    
    setChangedVal(e){
        
        const text = [ ...this.state.text ];
       
        let xx = Number(e.target.getAttribute('data-id'));
       
    for(var i=0; i<text.length;i++){
            if(text[i].id === xx){
                console.log('weeeeeeeee')
                    text[i].done = true;
            }
        }

        this.setState({
                text: text,
            })
           
    }   
    showAll(e){
        e.preventDefault();
        const text = [ ...this.state.text ];
         this.setState({
                arrayToDisplay: text,
            })
        
    }

    showActive(e){
         e.preventDefault();
        
        console.log('showActive')
         const text = [ ...this.state.text ];
         var newarray = text.filter( (cc) =>  cc.done === false);
         console.log(newarray);
         this.setState({
                arrayToDisplay: newarray,
            })

    }

    showCompleted(e){
         e.preventDefault();
        
        console.log('showActive')
         const text = [ ...this.state.text ];
         var newarray = text.filter( (cc) =>  cc.done === true);
         console.log(newarray);
         this.setState({
                arrayToDisplay: newarray,
            })
    }
}

